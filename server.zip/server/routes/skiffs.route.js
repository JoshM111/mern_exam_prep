// import controllers
const TolmanSkiffsController = require('../controllers/skiffs.controller');
// create the valid routes
module.exports = (app) => {
    app.get('/api/skiffs', TolmanSkiffsController.getAll);
    app.post('/api/skiffs', TolmanSkiffsController.create);
    app.get('/api/skiffs/:id', TolmanSkiffsController.getOne);
    app.put('/api/skiffs/:id', TolmanSkiffsController.update);
    // put and update do the same thing however put is the preferred method
    app.delete('/api/skiffs/:id', TolmanSkiffsController.delete);
}
